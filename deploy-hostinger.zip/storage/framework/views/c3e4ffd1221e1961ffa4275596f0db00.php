<footer>
  <div class="fg">
    <div>
      <a class="logo" href="<?php echo e(route('home')); ?>">
        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Logo PT Mahardika Logam Persada" width="79" height="40" loading="lazy">
        <span class="nm">PT Mahardika<br>Logam Persada</span>
      </a>
      <p>Perdagangan logam, pengadaan material industri, dan pengelolaan aset industri.</p>
    </div>
    <div>
      <h4>Menu</h4>
      <ul>
        <li><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
        <li><a href="<?php echo e(route('about')); ?>">Tentang Kami</a></li>
        <li><a href="<?php echo e(route('team')); ?>">Tim</a></li>
        <li><a href="<?php echo e(route('contact')); ?>">Kontak</a></li>
      </ul>
    </div>
    <div>
      <h4>Kontak</h4>
      <ul>
        <li><a href="mailto:mahardikalogampersada4@gmail.com">mahardikalogampersada4@gmail.com</a></li>
        <li><a href="tel:+6282174026509">0821 7402 6509</a></li>
        <li><a href="tel:+6285719110360">0857 1911 0360</a></li>
      </ul>
    </div>
    <div>
      <h4>Alamat</h4>
      <p>Buaran I RT 003 RW 008, Kel. Jatinegara, Kec. Cakung, Jl. Pengarengan No. 93, Jakarta Timur 13910</p>
    </div>
  </div>
  <div class="copy">© 2026 PT Mahardika Logam Persada. Seluruh hak cipta dilindungi.</div>
</footer>
<?php /**PATH C:\laragon\www\company-profile-ptmahardikalogam\resources\views/partials/footer.blade.php ENDPATH**/ ?>