<header id="hd">
  <a class="logo" href="<?php echo e(route('home')); ?>" aria-label="Beranda">
    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Logo PT Mahardika Logam Persada" width="67" height="34">
    <span class="nm">PT Mahardika<br>Logam Persada</span>
  </a>
  <button id="mb" aria-label="Buka menu" aria-expanded="false">☰</button>
  <nav id="nv">
    <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'on' : ''); ?>" data-p="beranda">Beranda</a>
    <a href="<?php echo e(route('about')); ?>" class="<?php echo e(request()->routeIs('about') ? 'on' : ''); ?>" data-p="tentang">Tentang Kami</a>
    <a href="<?php echo e(route('team')); ?>" class="<?php echo e(request()->routeIs('team') ? 'on' : ''); ?>" data-p="tim">Tim</a>
    <a class="cta <?php echo e(request()->routeIs('contact*') ? 'on' : ''); ?>" href="<?php echo e(route('contact')); ?>" data-p="kontak">Hubungi Kami</a>
  </nav>
</header>
<?php /**PATH C:\laragon\www\company-profile-ptmahardikalogam\resources\views/partials/navbar.blade.php ENDPATH**/ ?>